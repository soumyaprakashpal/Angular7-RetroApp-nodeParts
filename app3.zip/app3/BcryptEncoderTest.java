package com.retro.rest.webservices.restfulwebservices;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class BcryptEncoderTest {

	public static void main(String[] args) {
		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

		for (int i = 1; i <= 10; i++) {
			String encodedString = encoder.encode("SignUp");
			System.out.println(encodedString);
		}


	}

	public String getEncryptedPassword(String password) {
		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
		String encodedString = null;
		for (int i = 1; i <= 10; i++) {
			encodedString = encoder.encode(password);
		}
		return encodedString;
	}

}
