package com.retro.rest.webservices.restfulwebservices.todo;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.retro.rest.webservices.restfulwebservices.BcryptEncoderTest;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class RetroResource {

	List<Retro> retrolist = new ArrayList<>();
	List<Comments> commentlist = new ArrayList<>();

	@Autowired
	RetroRepository retros;

	@Autowired
	CommentsRepository comments;

	@PostMapping("/retrospec/users/{username}/retros")
	public ResponseEntity<Void> createTodo(@PathVariable String username, @RequestBody Retro retro) {

		// Todo createdTodo = todoService.save(todo);
		retro.setUsername(username);
		System.out.println(retro.getAgileTeamName());
		retrolist.add(retro);
		retros.setRetros(retrolist);
		// Location
		// Get current resource url
		/// {id}
		URI uri = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(retro.getUniqueId())
				.toUri();

		return ResponseEntity.created(uri).build();
	}

	@GetMapping("/retrospec/users/{username}/retros/{id}")
	public Retro getRetro(@PathVariable String username, @PathVariable long id) {
		for (Retro myR : retros.getRetros()) {
			if (myR.getUniqueId() == id) {
				// System.out.println(myR.getRetroName());
				return myR;
			}
		}
		return null;
	}

	@PostMapping("/retrospec/users/{id}/comments")
	public ResponseEntity<Void> addComments(@PathVariable long id, @RequestBody Comments comment) {

		// Todo createdTodo = todoService.save(todo);
		comment.setUniqueId(id);
		System.out.println(comment.getWentwell());
		commentlist.add(comment);
		comments.setComments(commentlist);
		
		// Location
		// Get current resource url
		/// {id}
		URI uri = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(comment.getUniqueId())
				.toUri();

		return ResponseEntity.created(uri).build();
	}
	
	
	@GetMapping("/retrospec/users/{username}/comments/{id}")
	public List<Comments> getComments(@PathVariable String username,@PathVariable long id) {
		List<Comments> comms=new ArrayList<>();
		for (Comments comm : comments.getComments()) {
			if (comm.getUniqueId()==id) {
				// System.out.println(myR.getRetroName());
				comms.add(comm);
			}
		}
		System.out.println("i am in list");
		comms.stream().forEach(System.out::println);
		return  comms;
	}
	
	
	@PostMapping("/retrospec/users/registration")
	public ResponseEntity<Void> createUser(@RequestBody User user) {

		System.out.println(user);
		BcryptEncoderTest bcrypt=new BcryptEncoderTest();
		String password=bcrypt.getEncryptedPassword(user.getPassword());
		
		URI uri = ServletUriComponentsBuilder.fromCurrentRequest().path("/{username}").buildAndExpand(user.getUsername())
				.toUri();

		return ResponseEntity.created(uri).build();
	}

}
