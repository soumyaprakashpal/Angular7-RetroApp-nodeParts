import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  isUserNameExist:boolean=false;
  isRegistered:boolean=false;
  Role: any = ['Admin', 'User','Other']
  firstname
  lastname
  username
  password
  teamname
  userRole

  constructor(private router: Router
    ) { }

  ngOnInit() {
  }

  backToLogin() {
    this.router.navigate(['login'])
   }

   checkAvailableUsername(){
    this.isUserNameExist=true;
   }

   changeUserRole(){
     console.log(this.userRole)
   }

   submitUserDetails(){
    this.isRegistered=true;
   }

}
