import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { RETRO_API_URL } from 'src/app/app.constants';
import { Retro, Comments } from 'src/app/joinretro/joinretro.component';
import { User } from 'src/app/signup/signup.component';


@Injectable({
  providedIn: 'root'
})
export class RetroDataService {

  constructor(
    private http:HttpClient
    ) { }


    createRetro(username:String, retro:Retro){
      return this.http.post(
                `${RETRO_API_URL}/users/${username}/retros`
                  , retro);
    }


    retrieveRetro(username:String, id:number){
      return this.http.get<Retro>(`${RETRO_API_URL}/users/${username}/retros/${id}`);
    }

    addComments(id:number, comments:Comments){
      return this.http.post(
                `${RETRO_API_URL}/users/${id}/comments`
                  , comments);
    }

    retrieveComments( username:String, id:number){
      return this.http.get<Comments[]>(`${RETRO_API_URL}/users/${username}/comments/${id}`);
    }


    createUser(user:User){
      return this.http.post(
                `${RETRO_API_URL}/users/registration`
                  , user);
    }
}
